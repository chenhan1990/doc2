package com.xxl.job.executor.test;

import org.junit.Test;

/*@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration*/
/*@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class ,webEnvironment= SpringBootTest.WebEnvironment.DEFINED_PORT)*/
public class XxlJobExecutorExampleBootApplicationTests {

	@Test
	public void test() {

	}

}